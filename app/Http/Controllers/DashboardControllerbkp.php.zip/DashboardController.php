<?php

namespace App\Http\Controllers;

use App\Exports\AfiliadosExport;
use App\Models\Afiliado;
use App\Models\AfiliadoCategoria;
use App\Models\AfiliadoRegiao;
use App\Models\Bairro;
use App\Models\CartaoCnpj;
use App\Models\Categoria;
use App\Models\Condominio;
use App\Models\Configuracao;
use App\Models\ContratoSocial;
use App\Models\Franqueado;
use App\Models\FranqueadoRegiao;
use App\Models\FranqueadoRegiaoPlanoDisponibilizado;
use App\Models\Orcamento;
use App\Models\Parceiro;
use App\Models\PlanoAssinaturaAfiliadoRegiao;
use App\Models\Regiao;
use App\Models\Sindico;
use App\Models\UsuarioApp;
use App\Models\Vistoria;
use App\Uteis\Formatacao;
use App\Uteis\ModusOperandiStatus;
use App\Uteis\StatusOrcamento;
use App\Uteis\StatusPlano;
use App\Uteis\StatusVistoria;
use App\Uteis\Util;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class DashboardController extends Controller
{
    /**
     * Verifica a url e redireciona para index correta.
     * Caso o usuario não estiver logado redireciona para a página de login.
     */
    public function index()
    {
        if (Auth::guard($this->guard)->check()) {
            switch ($this->url) {
                case 'admin_franqueado':
                    return $this->populateFranqueadoIndex();
                    break;
                default:
                    return $this->populateAdminIndex();
                    break;
            }
        } else {
            return redirect()->route($this->url . '.login');
        }
    }
    /**
     * Verifica a url e redireciona para a página de pendências correta.
     * Caso o usuario não estiver logado redireciona para a página de login.
     **/
    public function pendencias()
    {
        if (Auth::guard($this->guard)->check()) {
            switch ($this->url) {
                case 'admin_franqueado':
                    return $this->getPendenciasFranqueado();
                    break;
                default:
                    return $this->getPendenciasAdmin();
                    break;
            }
            return $this->getPendencias();
        } else {
            return redirect()->route($this->url . '.login');
        }
    }
    /** 
     * Pega as informações necessárias para preencher a index do franqueado
     **/
    private function populateFranqueadoIndex()
    {
        $afiliados_inativos = Afiliado::where('status', 'inativo')->count();
        $afiliados_pendentes = Afiliado::where('status', 'pendente')->count();
        $valor_planos_afiliados_ativos = AfiliadoRegiao::join('plano_assinatura_afiliado_regiao', 'plano_assinatura_afiliado_regiao.id', 'plano_assinatura_afiliado_regiao_id')
            ->join('afiliado', 'afiliado.id', 'afiliado_regiao.afiliado_id')
            ->distinct()->where('afiliado.status', 'ativo')->sum('plano_assinatura_afiliado_regiao.valor');
        $franqueadoRegioes = FranqueadoRegiao::where("franqueado_id", $this->user_franqueado->id)->where("status", "ativo")->orderBy("id", "desc")->get();

        $afiliados = Afiliado::join('afiliado_regiao', 'afiliado_regiao.afiliado_id', 'afiliado.id')
            ->whereIn('afiliado_regiao.regiao_id', function ($query) {
                $query->select('regiao_id')
                    ->from('franqueado_regiao')
                    ->where('franqueado_regiao.franqueado_id', Auth::guard('franqueados')->user()->id);
            })->orWhere("franqueado_id", $this->user_franqueado->id)->distinct()->select('afiliado.*')->orderBy("id", "DESC")->limit(10)->get();

        $afiliadosLnha = Afiliado::get();
        $afiliados = [];
        foreach ($afiliadosLnha as $afiliado) {
            $afiliadoRegioes = AfiliadoRegiao::where("afiliado_id", $afiliado->id)->get();
            foreach ($afiliadoRegioes as $afiliadoRegiao) {
                foreach($franqueadoRegioes as $franqueadoRegiaoLinha){
                    if($franqueadoRegiaoLinha->regiao_id==$franqueadoRegiaoLinha->regiao_id){
                        foreach ($franqueadoRegioes as $franqueadoREgiao) {
                            if ($afiliadoRegiao->regiao_id == $franqueadoREgiao->regiao_id) {
                                $afiliados[$afiliado->id] = $afiliado;
                            }
                        }
                    }
                }
            }
        }

        $afiliadosLnha = Afiliado::where("franqueado_id", $this->user_franqueado->id)->get();
        foreach ($afiliadosLnha as $afiliado) {
            $afiliados[$afiliado->id] = $afiliado;
        }

        if ($afiliados)
            krsort($afiliados);

        $afiliadosAux = $afiliados;
        $afiliados = [];
        foreach ($afiliadosAux as $afiliado) {
            if (count($afiliados) == 10) {
                break;
            }
            $afiliados[] = $afiliado;
        }


        $franqueadoRegioes = FranqueadoRegiao::where("franqueado_id", $this->user_franqueado->id)->where("status", "ativo")->orderBy("id", "desc")->get();
        $planos_ativos = 0;
        $valor_planos_afiliados_ativos = 0;
        $valor_planos_afiliados_ativos_com_dessconto = 0;
        $t = [];
        foreach ($franqueadoRegioes as $franqueado_regiao) {
            $afiliadosRegioes = AfiliadoRegiao::where("regiao_id", $franqueado_regiao->regiao_id)->orderBy("id", "desc")->get();
            foreach ($afiliadosRegioes as $afiliadoRegiao) {
                if($franqueado_regiao->regiao_id==$afiliadoRegiao->regiao_id){
                    $planoAfiliado = PlanoAssinaturaAfiliadoRegiao::where("id", $afiliadoRegiao->plano_assinatura_afiliado_regiao_id)->whereIn("statusPlano", [StatusPlano::$ATIVO, StatusPlano::$INADIMPLENTE])->first();
                    if ($planoAfiliado) {
                        $afiliado = Afiliado::where("id", $afiliadoRegiao->afiliado_id)->first();
                        if ($afiliado) {
                            $usuarioApp = UsuarioApp::where("id", $afiliado->usuario_app_id)->first();
                            if ($usuarioApp) {
                                if ($planoAfiliado->statusPlano == StatusPlano::$ATIVO) {
                                    $planos_ativos++;
                                    $valor_planos_afiliados_ativos += $planoAfiliado->valor;
                                    $valor_planos_afiliados_ativos_com_dessconto += $planoAfiliado->valor - ($planoAfiliado->valor * ($planoAfiliado->desconto / 100));
                                }
                                $t[] = [
                                    "razao_social" => $afiliado->razao_social . " (" . $planoAfiliado->asaas_customer_id . ")",
                                    "nome_plano" => $planoAfiliado->nome . ". Criado em \n" . Formatacao::data($planoAfiliado->data_cadastro),
                                    "valor" => "R$ " . $planoAfiliado->valor,
                                    "valor_desconto" => "R$ " . ($planoAfiliado->valor - ($planoAfiliado->valor * ($planoAfiliado->desconto / 100))),
                                    "afiliado_id" => $afiliado->id,
                                    "desconto" => $planoAfiliado->desconto,
                                    "data_expiracao" => $planoAfiliado->data_expiracao ? Formatacao::data($planoAfiliado->data_expiracao) : "Gerenciado pela franquia",
                                    "cor" => $planoAfiliado->statusPlano == StatusPlano::$ATIVO ? "--success" : "--warning"
                                ];
                            }
                        }
                    }
                }
            }
        }
        $valor_planos_afiliados_ativos = Formatacao::prefixoSufixo($valor_planos_afiliados_ativos);
        $valor_planos_afiliados_ativos_com_dessconto = Formatacao::prefixoSufixo($valor_planos_afiliados_ativos_com_dessconto);

        $categoriasPendentesShow = [];
        $categoriasPendentes = AfiliadoCategoria::where("status", "pendente")->orderBy("id", "desc")->get();
        foreach ($categoriasPendentes as $categoriaPendente) {
            $regioesAfiliado = AfiliadoRegiao::where("afiliado_id", $categoriaPendente->afiliado_id)->get();
            foreach ($regioesAfiliado as $regiaoAfiliado) {
                $franqueadoRegiao = FranqueadoRegiao::where("regiao_id", $regiaoAfiliado->regiao_id)->where("status", "ativo")->orderBy("id", "desc")->first();
                if ($franqueadoRegiao->franqueado_id == $this->user_franqueado->id) {
                    $categoriasPendentesShow[$categoriaPendente->id] = $categoriaPendente;
                }
            }
        }

        $documentosPendentesShow = [];
        $totalDocPendentes = 0;
        $cartoesCnpjPendente = CartaoCnpj::where("status", "pendente")->orderBy("id", "desc")->get();
        foreach ($cartoesCnpjPendente as $docPendente) {
            $docPendente['tipo'] = "cartao-cnpj";
            $documentosPendentesShow[$docPendente->afiliado_id][] = $docPendente;
            $totalDocPendentes++;
        }

        $contratoSocialPendente = ContratoSocial::where("status", "pendente")->orderBy("id", "desc")->get();
        foreach ($contratoSocialPendente as $docPendente) {
            $docPendente['tipo'] = "contrato-social";
            $documentosPendentesShow[$docPendente->afiliado_id][] = $docPendente;
            $totalDocPendentes++;
        }


        $solicitacoesLinha = Orcamento::join('franqueado_regiao', 'franqueado_regiao.regiao_id', 'orcamento.regiao_id')->where('franqueado_regiao.franqueado_id', Auth::guard('franqueados')->id())->distinct()->select('orcamento.*')->orderBy('orcamento.id', 'desc')->get();
        $solicitacoes = [];

        foreach ($solicitacoesLinha as $key => $value) {

            if ($value->status <= 4 || $value->status == 10) {
                $value->bairroFK = Bairro::where("id", $value->condominio->bairro_id)->first();
                $solicitacoes[] = $value;
            }
        }

        $sindicos = [];
        $sindicosAll = Sindico::where("franqueado_id", null)->orWhere("franqueado_id", $this->user_franqueado->id)->orderBy("id", "desc")->get();
        foreach ($sindicosAll as $sindico) {
            $condominios = Condominio::where("sindico_id", $sindico->id)->get();
            $addSindico = false;
            foreach ($condominios as $c) {

                if (isset($c->bairro()->first()->regiao)) {
                    $franqueado_condominio_id = FranqueadoRegiao::where("regiao_id", $c->bairro()->first()->regiao->id)->orderBy("id", "desc")->first()->franqueado_id;
                    if ($franqueado_condominio_id == $this->user_franqueado->id) {
                        $addSindico = true;
                    }
                } else if ($this->user_franqueado->id == 1) {
                    $addSindico = true;
                }
            }
            if ($addSindico) {
                $sindicos[$sindico->id] = $sindico;
            }
        }

        if ($sindicos)
            krsort($sindicos);

        $sindicosAux = $sindicos;
        $sindicos = [];
        foreach ($sindicosAux as $s) {
            if (count($sindicos) == 10) {
                break;
            }
            $sindicos[] = $s;
        }

        $fid = Auth::guard('franqueados')->user()->id;
        $franqueadoRegioes = FranqueadoRegiao::where("franqueado_id", $this->user_franqueado->id)->where("status", "ativo")->orderBy("id", "desc")->get();

        $afiliadosAll = Afiliado::join('afiliado_regiao', 'afiliado_regiao.afiliado_id', 'afiliado.id')
            ->whereIn('afiliado_regiao.regiao_id', function ($query) {
                $query->select('regiao_id')
                    ->from('franqueado_regiao')
                    ->where("franqueado_regiao.status", "ativo")
                    ->where('franqueado_regiao.franqueado_id', Auth::guard('franqueados')->user()->id);
            })->distinct()->select('afiliado.*')->orderBy("afiliado.id", "desc")->get();

        $afiliados_sem_contrato = 0;
        $documentosPendentesShow = [];
        $totalDocPendentes = 0;
        $afiliados_sem_contrato_result = [];
        foreach ($afiliadosAll as $afiliadoLinha) {
            $afiliadoRegiaoAuxiliarLista = AfiliadoRegiao::where("afiliado_id", $afiliadoLinha->id)->where("modo", Util::getModusOperandi())->get();

            foreach ($afiliadoRegiaoAuxiliarLista as $afiliadoRegiaoAuxiliar) {
                

                $regiao = Regiao::where("id", $afiliadoRegiaoAuxiliar->regiao_id)->first();

                foreach($franqueadoRegioes as $franqueadoRegiaoLinha){
                    if($regiao && $franqueadoRegiaoLinha->regiao_id==$regiao->id){
                            $afiliado = Afiliado::where("id", $afiliadoRegiaoAuxiliar->afiliado_id)->first();
                            if ($regiao && $afiliado) {
                                $contrato = PlanoAssinaturaAfiliadoRegiao::where("id", $afiliadoRegiaoAuxiliar->plano_assinatura_afiliado_regiao_id)->whereNull("arquivo_original")->first();
                                if($contrato){
                                    $franqueado_regiao_plano_disponibilizado = FranqueadoRegiaoPlanoDisponibilizado::where("id", $contrato->franqueado_regiao_plano_disponibilizado_id)->first();
                                    if($franqueado_regiao_plano_disponibilizado){
                                        $franqueado_regiao = FranqueadoRegiao::where("id", $franqueado_regiao_plano_disponibilizado->franqueado_regiao_id)->first();
                                        if($franqueado_regiao){
                                            if ($contrato && $franqueado_regiao->status=="ativo" && ($contrato->statusPlano==StatusPlano::$ATIVO || $contrato->statusPlano==StatusPlano::$PENDENTE)) {
                                                //$afiliados_sem_contrato++;
                                                $afiliados_sem_contrato_result[$afiliado->id] = $afiliado;
                                            } else if ($contrato && $franqueado_regiao->status=="inativo" && ($contrato->statusPlano==StatusPlano::$ATIVO || $contrato->statusPlano==StatusPlano::$PENDENTE)){
                                                $afiliados_sem_contrato_result[$afiliado->id] = $afiliado;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
            }

            $cartoesCnpjPendente = CartaoCnpj::where("afiliado_id", $afiliadoLinha->id)->where("status", "pendente")->orderBy("id", "desc")->get();
            foreach ($cartoesCnpjPendente as $docPendente) {
                $afiliado = Afiliado::where("id", $docPendente->afiliado_id)->first();

                if($afiliado){
                    $docPendente['tipo'] = "cartao-cnpj";
                    $documentosPendentesShow[$docPendente->afiliado_id][] = $docPendente;
                    $totalDocPendentes++;
                }
                
            }

            $contratoSocialPendente = ContratoSocial::where("afiliado_id", $afiliadoLinha->id)->where("status", "pendente")->orderBy("id", "desc")->get();
            foreach ($contratoSocialPendente as $docPendente) {
                $afiliado = Afiliado::where("id", $docPendente->afiliado_id)->first();

                if($afiliado){
                    $docPendente['tipo'] = "contrato-social";
                    $documentosPendentesShow[$docPendente->afiliado_id][] = $docPendente;
                    $totalDocPendentes++;
                }
            }
        }

        $afiliados_sem_contrato = count($afiliados_sem_contrato_result);

        // Solicitações
        $solicitacoesEmAndamentoAux = Orcamento::whereIn("status", [1, 2, 3, 4, 10])->where("modo", Util::getModusOperandi())->get();
        $solicitacoesEmAndamento = 0;
        foreach ($solicitacoesEmAndamentoAux as $solicitacao) {
            $franqueadoRegiao = FranqueadoRegiao::where("franqueado_id", $this->user_franqueado->id)->where("regiao_id", $solicitacao->regiao_id)->where("status", "ativo")->orderBy("id", "desc")->first();
            if ($franqueadoRegiao) {
                $solicitacoesEmAndamento++;
            }
        }

        $solicitacoesCanceladasAux = Orcamento::whereIn("status", [6, 7, 8, 9])->where("modo", Util::getModusOperandi())->get();
        $solicitacoesCanceladas = 0;
        foreach ($solicitacoesCanceladasAux as $solicitacao) {
            $franqueadoRegiao = FranqueadoRegiao::where("franqueado_id", $this->user_franqueado->id)->where("regiao_id", $solicitacao->regiao_id)->where("status", "ativo")->orderBy("id", "desc")->first();
            if ($franqueadoRegiao) {
                $solicitacoesCanceladas++;
            }
        }

        $solicitacoesDisputaAux = Vistoria::where("status", StatusVistoria::$PENDENTE)->get();
        $solicitacoesDisputa = 0;
        foreach ($solicitacoesDisputaAux as $vistoria) {
            $solicitacao = Orcamento::where("id", $vistoria->orcamento_id)->first();
            if ($solicitacao) {
                $franqueadoRegiao = FranqueadoRegiao::where("franqueado_id", $this->user_franqueado->id)->where("regiao_id", $solicitacao->regiao_id)->where("status", "ativo")->orderBy("id", "desc")->first();
                if ($franqueadoRegiao) {
                    $solicitacoesDisputa++;
                }
            }
        }
        // END Solicitações
        return view($this->url . '.index', compact(
            'solicitacoesDisputa',
            'solicitacoesCanceladas',
            'solicitacoesEmAndamento',
            'afiliados_sem_contrato',
            'franqueadoRegioes',
            'fid',
            'afiliados_sem_contrato_result',
            'totalDocPendentes',
            'documentosPendentesShow',
            'categoriasPendentesShow',
            'planos_ativos',
            'afiliados_inativos',
            'afiliados_pendentes',
            'valor_planos_afiliados_ativos',
            'valor_planos_afiliados_ativos_com_dessconto',
            'solicitacoes',
            'sindicos',
            'afiliados',
            't'
        ));
    }
    /** 
     * Pega as informações necessárias para preencher a index do admin
     **/
    private function populateAdminIndex()
    {
        $afiliados_inativos = "--";
        $afiliados_pendentes = Afiliado::where('status', 'pendente')->count();
        $valor_planos_afiliados_ativos = AfiliadoRegiao::join('plano_assinatura_afiliado_regiao', 'plano_assinatura_afiliado_regiao.id', 'plano_assinatura_afiliado_regiao_id')
            ->join('afiliado', 'afiliado.id', 'afiliado_regiao.afiliado_id')
            ->distinct()->where('afiliado.status', 'ativo')->sum('plano_assinatura_afiliado_regiao.valor');

        $config = Configuracao::orderBy("id", "desc")->first();

        $afiliados = Afiliado::orderBy("id", "desc")->limit(10)->get();
        $afiliadosSemRegiao = 0;

        $afiliadosAux = Afiliado::orderBy("id", "desc")->get();
        foreach ($afiliadosAux as $afiliado) {
            $afiliadoRegiao = AfiliadoRegiao::where("afiliado_id", $afiliado->id)->first();
            if (!$afiliadoRegiao) {
                $afiliadosSemRegiao++;
            }
        }

        /*$planos_ativos_afiliado = AfiliadoRegiao::join('plano_assinatura_afiliado_regiao', 'plano_assinatura_afiliado_regiao.id', 'plano_assinatura_afiliado_regiao_id')
            ->join('afiliado', 'afiliado.id', 'afiliado_regiao.afiliado_id')
            ->distinct()->where('plano_assinatura_afiliado_regiao.statusPlano', '1')->get();*/

        $planos_ativos_afiliado = PlanoAssinaturaAfiliadoRegiao::where("statusPlano", 1)->get();
        $planos_ativos = 0;
        $valor_planos_afiliados_ativos = 0;
        foreach ($planos_ativos_afiliado as $plano_ativo) {
            $afiliado_regiao = AfiliadoRegiao::where("plano_assinatura_afiliado_regiao_id", $plano_ativo->id)->first();
            if ($afiliado_regiao) {
                $afiliado = Afiliado::where("id", $afiliado_regiao->afiliado_id)->first();
                if ($afiliado) {
                    $usuarioApp = UsuarioApp::where("id", $afiliado->usuario_app_id)->first();
                    if ($usuarioApp) {
                        $planos_ativos++;
                        $valor_planos_afiliados_ativos += $plano_ativo->valor;
                    }
                }
            }
        }

        $afiliados_ativos = $planos_ativos;

        $documentosPendentesShow = [];
        $totalDocPendentes = 0;
        $cartoesCnpjPendente = CartaoCnpj::where("status", "pendente")->orderBy("id", "desc")->get();
        foreach ($cartoesCnpjPendente as $docPendente) {
            $docPendente['tipo'] = "cartao-cnpj";
            $documentosPendentesShow[$docPendente->afiliado_id][] = $docPendente;
            $totalDocPendentes++;
        }

        $contratoSocialPendente = ContratoSocial::where("status", "pendente")->orderBy("id", "desc")->get();
        foreach ($contratoSocialPendente as $docPendente) {
            $docPendente['tipo'] = "contrato-social";
            $documentosPendentesShow[$docPendente->afiliado_id][] = $docPendente;
            $totalDocPendentes++;
        }



        $parceiros_ativos = Parceiro::where('status', 'ativo')->count();
        $parceiros_inativos = Parceiro::where('status', 'inativos')->count();
        $valor_planos_parceiros_ativos = Parceiro::join('plano_disponivel_franqueado', 'plano_disponivel_franqueado.id', 'parceiros.plano_id')->where('parceiros.status', 'ativo')->sum('plano_disponivel_franqueado.valor');
        // $valor_planos_parceiros_ativos = Formatacao::prefixoSufixo($valor_planos_afiliados_ativos);
        $solicitacoesLinha = Orcamento::where('orcamento.status', '<>', null)->select('orcamento.*')->orderBy('orcamento.id', 'desc')->get();

        $afiliados = Afiliado::orderBy("id", "desc")->limit(10)->get();

        $solicitacoes = [];

        foreach ($solicitacoesLinha as $key => $value) {

            if ($value->status <= 4 || $value->status == 10) {
                $value->bairroFK = Bairro::where("id", $value->condominio->bairro_id)->first();
                $solicitacoes[] = $value;
            }
        }
        //Solicitações
        $solicitacoesEmAndamento = Orcamento::whereIn("status", [1, 2, 3, 4, 10])->get()->count();
        $solicitacoesCanceladas = Orcamento::whereIn("status", [6, 77, 8, 9])->count();
        $solicitacoesDisputa = Vistoria::where("status", StatusVistoria::$PENDENTE)->count();
        // END Solicitações

        $franqueados = Franqueado::orderBy("id", "desc")->limit(10)->get();
        $categoriasPendentesShowAux = AfiliadoCategoria::where("status", "pendente")->get();
        $categoriasPendentesShow = [];
        foreach ($categoriasPendentesShowAux as $categoriaPendente) {
            $afiliado = Afiliado::where("id", $categoriaPendente->afiliado_id)->first();
            $categoria = Categoria::where("id", $categoriaPendente->categoria_id)->first();
            if ($afiliado && $categoria) {
                $categoriasPendentesShow[] = $categoriaPendente;
            }
        }
        $valor_planos_afiliados_ativos = Formatacao::prefixoSufixo($valor_planos_afiliados_ativos);
        // Popular graficos
        $franqueados = Franqueado::all();
        $chartQA = $this->populateChartQA($franqueados);
        $condominios = Condominio::all();
        $chartQS = $this->populateChartQS($condominios);
        $chartQSo = $this->populateChartQSo($franqueados);
        // END Popular graficos
        // Popular table categorias
        $categorias = Categoria::all();
        foreach ($categorias as $categoria) {
            $categoria->afiliados = 0;
            $categoria->concluidas = 0;
            $categoria->canceladas = 0;
            foreach ($categoria->afiliadoCategorias as $afiliadoCategoria) {
                if (optional($afiliadoCategoria->afiliado)->status == 'ativo') {
                    $categoria->afiliados++;
                };
            }
            foreach ($categoria->orcamentos as $orcamento) {
                if ($orcamento->status == StatusOrcamento::$FINALIZADO) {
                    $categoria->concluidas++;
                }
                if (
                    $orcamento->status == StatusOrcamento::$CANCELADO_PELO_ADMIN ||
                    $orcamento->status == StatusOrcamento::$CANCELADO_PELO_FRANQUEADO ||
                    $orcamento->status == StatusOrcamento::$CANCELADO_PELO_SINDICO ||
                    $orcamento->status == StatusOrcamento::$CANCELADO_PELO_AFILIADO
                ) {
                    $categoria->canceladas++;
                }
            }
        }
        // END Popular table categorias

        // Popular table regioes
        $franqueadoRegioes = FranqueadoRegiao::where('status', 'ativo')->get();
        foreach ($franqueadoRegioes as $franqueadoRegiao) {
            $franqueadoRegiao->afiliados = 0;
            $franqueadoRegiao->concluidas = 0;
            $franqueadoRegiao->canceladas = 0;
            $orcamentos =  Orcamento::where('regiao_id', $franqueadoRegiao->regiao_id)->get();
            $franqueadoRegiao->orcamentos = $orcamentos;
            foreach ($orcamentos as $orcamento) {
                if ($orcamento->status == StatusOrcamento::$FINALIZADO) {
                    $franqueadoRegiao->concluidas++;
                }
                if (
                    $orcamento->status == StatusOrcamento::$CANCELADO_PELO_ADMIN ||
                    $orcamento->status == StatusOrcamento::$CANCELADO_PELO_FRANQUEADO ||
                    $orcamento->status == StatusOrcamento::$CANCELADO_PELO_SINDICO ||
                    $orcamento->status == StatusOrcamento::$CANCELADO_PELO_AFILIADO
                ) {
                    $franqueadoRegiao->canceladas++;
                }
            }
        }
        // END Popular table regioes

        // Popular table vistorias
        $vistorias = Vistoria::whereIn('status', [StatusVistoria::$EM_ANDAMENTO, StatusVistoria::$PENDENTE])->get();
        $vistoriasResource = Vistoria::get();

        $vistorias = [];
        foreach ($vistoriasResource as $v) {
            $o = Orcamento::where("id", $v->orcamento_id)->first();
            if ($o && ($v->status == StatusVistoria::$EM_ANDAMENTO || $v->status == StatusVistoria::$PENDENTE)) {
                if ($this->url == "admin_franqueado") {
                    $franqueadoRegiao = FranqueadoRegiao::where("regiao_id", $o->regiao_id)->where("franqueado_id", $this->user_franqueado->id)->where("status", "ativo")->orderBy("id", "desc")->first();
                    if ($franqueadoRegiao) {
                        $vistorias[] = $v;
                    }
                } else {
                    $vistorias[] = $v;
                }
            }
        }
        // END Popular table vistorias
        return view(
            $this->url . '.index',
            compact(
                'config',
                'solicitacoesDisputa',
                'solicitacoesCanceladas',
                'solicitacoesEmAndamento',
                'afiliadosSemRegiao',
                'totalDocPendentes',
                'documentosPendentesShow',
                'categoriasPendentesShow',
                'franqueados',
                'afiliados_ativos',
                'afiliados_inativos',
                'afiliados_pendentes',
                'parceiros_ativos',
                'parceiros_inativos',
                'valor_planos_afiliados_ativos',
                'valor_planos_parceiros_ativos',
                'solicitacoes',
                'afiliados',
                'chartQA',
                'chartQS',
                'chartQSo',
                'categorias',
                'franqueadoRegioes',
                'vistorias'
            )
        );
    }
    /** 
     * Pega as informações necessárias para preencher o gráfico de 
     *  quantidade de afiliados por franqueado da index
     * @param /App/Models/Franqueado
     * @return Object
     **/
    private function populateChartQA($franqueados)
    {
        $chartQA = [
            "data" => [],
            "labels" => [],
            "colors" => '#727cf5',
            "min" => 0,
            "max" => 0
        ];
        $regioes = [];
        foreach ($franqueados as $franqueado) {
            foreach ($franqueado->franqueadoRegiao as $franqueadoRegiao) {
                if ($franqueadoRegiao->status == 'ativo') {
                    if (!in_array($franqueado->nome, $chartQA['labels'])) {
                        array_push($chartQA['labels'], $franqueado->nome);
                    }
                    if (!in_array($franqueadoRegiao->regiao_id, $regioes)) {
                        array_push($regioes, [$franqueadoRegiao->regiao_id, $franqueado->nome]);
                    }
                }
            }
        }
        $data = [];
        foreach ($regioes as  $regiaoDados) {
            $afiliadoRegioes = AfiliadoRegiao::where('regiao_id', $regiaoDados[0])->get();
            $numAfiliados = 0;
            foreach ($afiliadoRegioes as $afiliadoRegiao) {
                if (
                    $afiliadoRegiao->PlanoAssinaturaAfiliadoRegiao->statusPlano ==  1 &&
                    $afiliadoRegiao->PlanoAssinaturaAfiliadoRegiao->statusPlano == 1
                ) {
                    $numAfiliados++;
                }
            }
            if (key_exists($regiaoDados[1], $data)) {
                $data[$regiaoDados[1]]  += $numAfiliados;
            } else {
                $data[$regiaoDados[1]] = $numAfiliados;
            }
        }
        foreach ($data as $d) {
            if ($d > $chartQA['max']) {
                $chartQA['max'] = $d;
            }
            array_push($chartQA['data'], $d);
        }
        return $chartQA;
    }
    /** 
     * Pega as informações necessárias para preencher o gráfico de 
     *  quantidade de sindicos por franqueado da index
     * @param /App/Models/Condominio
     * @return Object
     **/
    private function populateChartQS($condominios)
    {
        $chartQS = [
            "data" => [],
            "labels" => [],
            "colors" => '#727cf5',
            "min" => 0,
            "max" => 0
        ];
        $sindicosFranqueado = [];
        foreach ($condominios as $condominio) {
            $franqueadoRegiao = FranqueadoRegiao::where('status', 'ativo')->where('regiao_id', $condominio->getRegiao())->first();
            if ($franqueadoRegiao != null) {
                if (!isset($sindicosFranqueado[$franqueadoRegiao->franqueado->nome], $sindicosFranqueado)) {
                    $sindicosFranqueado[$franqueadoRegiao->franqueado->nome] = [];
                }
                if (!in_array(optional($condominio->sindico)->id, $sindicosFranqueado[$franqueadoRegiao->franqueado->nome])) {
                    array_push($sindicosFranqueado[$franqueadoRegiao->franqueado->nome], optional($condominio->sindico)->id);
                }
                if (!in_array($franqueadoRegiao->franqueado->nome, $chartQS['labels'])) {
                    array_push($chartQS['labels'], $franqueadoRegiao->franqueado->nome);
                }
            }
        }
        foreach ($sindicosFranqueado as $sindicos) {
            array_push($chartQS['data'], sizeof($sindicos));
            if (sizeof($sindicos) > $chartQS['max']) {
                $chartQS['max']  = sizeof($sindicos);
            }
        }
        return $chartQS;
    }
    /** 
     * Pega as informações necessárias para preencher o gráfico de 
     *  quantidade de solicitações/orcamentos por franqueado da index
     * @param /App/Models/Franqueado
     * @return Object
     **/
    private function populateChartQSo($franqueados)
    {
        $chartQSo = [
            "data" => [],
            "labels" => [],
            "colors" => '#727cf5',
            "min" => 0,
            "max" => 0
        ];
        $regioes = [];
        foreach ($franqueados as $franqueado) {
            foreach ($franqueado->franqueadoRegiao as $franqueadoRegiao) {
                if ($franqueadoRegiao->status == 'ativo') {
                    if (!in_array($franqueado->nome, $chartQSo['labels'])) {
                        array_push($chartQSo['labels'], $franqueado->nome);
                    }
                    if (!in_array($franqueadoRegiao->regiao_id, $regioes)) {
                        array_push($regioes, [$franqueadoRegiao->regiao_id, $franqueadoRegiao->franqueado->nome]);
                    }
                }
            }
        }
        $data = [];

        foreach ($regioes as  $regiaoDados) {
            $numOrcamentos = Orcamento::where('regiao_id', $regiaoDados[0])->where('status', StatusOrcamento::$FINALIZADO)->count();
            if (key_exists($regiaoDados[1], $data)) {
                $data[$regiaoDados[1]]  += $numOrcamentos;
            } else {
                $data[$regiaoDados[1]] = $numOrcamentos;
            }
        }
        foreach ($data as $d) {
            if ($d > $chartQSo['max']) {
                $chartQSo['max'] = $d;
            }
            array_push($chartQSo['data'], $d);
        }
        return $chartQSo;
    }
    /** 
     * Pega as informações necessárias para preencher a pagina de pendências do franqueado
     **/
    private function getPendenciasFranqueado()
    {

        $categoriasPendentesShow = [];
        $categoriasPendentes = AfiliadoCategoria::where("status", "pendente")->orderBy("id", "desc")->get();
        foreach ($categoriasPendentes as $categoriaPendente) {
            $regioesAfiliado = AfiliadoRegiao::where("afiliado_id", $categoriaPendente->afiliado_id)->get();
            foreach ($regioesAfiliado as $regiaoAfiliado) {
                $franqueadoRegiao = FranqueadoRegiao::where("regiao_id", $regiaoAfiliado->regiao_id)->where("status", "ativo")->orderBy("id", "desc")->first();
                if ($franqueadoRegiao->franqueado_id == $this->user_franqueado->id) {
                    $categoriasPendentesShow[$categoriaPendente->id] = $categoriaPendente;
                }
            }
        }

        $documentosPendentesShow = [];
        $totalDocPendentes = 0;
        $cartoesCnpjPendente = CartaoCnpj::where("status", "pendente")->orderBy("id", "desc")->get();
        foreach ($cartoesCnpjPendente as $docPendente) {
            $docPendente['tipo'] = "cartao-cnpj";
            $documentosPendentesShow[$docPendente->afiliado_id][] = $docPendente;
            $totalDocPendentes++;
        }

        $contratoSocialPendente = ContratoSocial::where("status", "pendente")->orderBy("id", "desc")->get();
        foreach ($contratoSocialPendente as $docPendente) {
            $docPendente['tipo'] = "contrato-social";
            $documentosPendentesShow[$docPendente->afiliado_id][] = $docPendente;
            $totalDocPendentes++;
        }



        $afiliadosAll = Afiliado::join('afiliado_regiao', 'afiliado_regiao.afiliado_id', 'afiliado.id')
            ->whereIn('afiliado_regiao.regiao_id', function ($query) {
                $query->select('regiao_id')
                    ->from('franqueado_regiao')
                    ->where('franqueado_regiao.franqueado_id', Auth::guard('franqueados')->user()->id);
            })->distinct()->select('afiliado.*')->orderBy("afiliado.id", "desc")->get();

        $afiliados_sem_contrato = 0;
        $documentosPendentesShow = [];
        $totalDocPendentes = 0;
        $afiliados_inativos = 0;
        $afiliados_inativos_cont = [];

        foreach ($afiliadosAll as $afiliadoLinha) {
            $afiliadoRegiaoAuxiliarLista = AfiliadoRegiao::where("afiliado_id", $afiliadoLinha->id)->get();

            foreach ($afiliadoRegiaoAuxiliarLista as $afiliadoRegiaoAuxiliar) {
                if ($afiliadoRegiaoAuxiliar) {
                    $contrato = PlanoAssinaturaAfiliadoRegiao::where("id", $afiliadoRegiaoAuxiliar->plano_assinatura_afiliado_regiao_id)->where("statusPlano", 1)->where("arquivo_original", null)->first();
                    if ($contrato) {
                        $afiliados_sem_contrato++;
                    }

                    $contrato2 = PlanoAssinaturaAfiliadoRegiao::where("id", $afiliadoRegiaoAuxiliar->plano_assinatura_afiliado_regiao_id)->where("statusPlano", "in", [StatusPlano::$PENDENTE])->first();
                    if ($contrato2) {
                        $afiliados_inativos_cont[$afiliadoLinha->id] = $contrato2;
                    }
                }
            }

            $afiliados_inativos = count($afiliados_inativos_cont);



            $cartoesCnpjPendente = CartaoCnpj::where("afiliado_id", $afiliadoLinha->id)->where("status", "pendente")->orderBy("id", "desc")->get();
            foreach ($cartoesCnpjPendente as $docPendente) {
                $docPendente['tipo'] = "cartao-cnpj";
                $documentosPendentesShow[$docPendente->afiliado_id][] = $docPendente;
                $totalDocPendentes++;
            }

            $contratoSocialPendente = ContratoSocial::where("afiliado_id", $afiliadoLinha->id)->where("status", "pendente")->orderBy("id", "desc")->get();
            foreach ($contratoSocialPendente as $docPendente) {
                $docPendente['tipo'] = "contrato-social";
                $documentosPendentesShow[$docPendente->afiliado_id][] = $docPendente;
                $totalDocPendentes++;
            }
        }

        $vistorias = Vistoria::whereIn('status', [StatusVistoria::$EM_ANDAMENTO, StatusVistoria::$PENDENTE])->get();
        $vistoriasResource = Vistoria::get();
        $vistorias = [];
        foreach ($vistoriasResource as $v) {
            $o = Orcamento::where("id", $v->orcamento_id)->first();
            if ($o && ($v->status == StatusVistoria::$EM_ANDAMENTO || $v->status == StatusVistoria::$PENDENTE)) {
                if ($this->url == "admin_franqueado") {
                    $franqueadoRegiao = FranqueadoRegiao::where("regiao_id", $o->regiao_id)->where("franqueado_id", $this->user_franqueado->id)->where("status", "ativo")->orderBy("id", "desc")->first();
                    if ($franqueadoRegiao) {
                        $vistorias[] = $v;
                    }
                } else {
                    $vistorias[] = $v;
                }
            }
        }


        return view($this->url . '.pendencias', compact('vistorias', 'categoriasPendentesShow', 'documentosPendentesShow', 'totalDocPendentes'));
    }
    /** 
     * Pega as informações necessárias para preencher a pagina de pendências do admin
     **/
    private function getPendenciasAdmin()
    {
        $afiliados_inativos = Afiliado::where('status', 'inativo')->count();
        $afiliados_pendentes = Afiliado::where('status', 'pendente')->count();
        $valor_planos_afiliados_ativos = AfiliadoRegiao::join('plano_assinatura_afiliado_regiao', 'plano_assinatura_afiliado_regiao.id', 'plano_assinatura_afiliado_regiao_id')
            ->join('afiliado', 'afiliado.id', 'afiliado_regiao.afiliado_id')
            ->distinct()->where('afiliado.status', 'ativo')->sum('plano_assinatura_afiliado_regiao.valor');

        $documentosPendentesShow = [];
        $totalDocPendentes = 0;
        $cartoesCnpjPendente = CartaoCnpj::where("status", "pendente")->orderBy("id", "desc")->get();
        foreach ($cartoesCnpjPendente as $docPendente) {
            $docPendente['tipo'] = "cartao-cnpj";
            $afiliado = Afiliado::where("id", $docPendente->afiliado_id)->first();
            if($afiliado){
                $documentosPendentesShow[$docPendente->afiliado_id][] = $docPendente;
                $totalDocPendentes++;
            }
            
        }

        $contratoSocialPendente = ContratoSocial::where("status", "pendente")->orderBy("id", "desc")->get();
        foreach ($contratoSocialPendente as $docPendente) {
            $docPendente['tipo'] = "contrato-social";
            $afiliado = Afiliado::where("id", $docPendente->afiliado_id)->first();
            if($afiliado){
                $documentosPendentesShow[$docPendente->afiliado_id][] = $docPendente;
                $totalDocPendentes++;
            }
        }
        $categoriasPendentesShowAux = AfiliadoCategoria::where("status", "pendente")->get();
        $categoriasPendentesShow = [];
        foreach ($categoriasPendentesShowAux as $categoriaPendente) {
            $afiliado = Afiliado::where("id", $categoriaPendente->afiliado_id)->first();
            $categoria = Categoria::where("id", $categoriaPendente->categoria_id)->first();
            if ($afiliado && $categoria) {
                $categoriasPendentesShow[] = $categoriaPendente;
            }
        }

        // Popular table vistorias
        $vistorias = Vistoria::whereIn('status', [StatusVistoria::$EM_ANDAMENTO, StatusVistoria::$PENDENTE])->get();
        $vistoriasResource = Vistoria::get();

        $vistorias = [];
        foreach ($vistoriasResource as $v) {
            $o = Orcamento::where("id", $v->orcamento_id)->first();
            if ($o && ($v->status == StatusVistoria::$EM_ANDAMENTO || $v->status == StatusVistoria::$PENDENTE)) {
                if ($this->url == "admin_franqueado") {
                    $franqueadoRegiao = FranqueadoRegiao::where("regiao_id", $o->regiao_id)->where("franqueado_id", $this->user_franqueado->id)->where("status", "ativo")->orderBy("id", "desc")->first();
                    if ($franqueadoRegiao) {
                        $vistorias[] = $v;
                    }
                } else {
                    $vistorias[] = $v;
                }
            }
        }

        return view($this->url . '.pendencias', compact('vistorias', 'categoriasPendentesShow', 'documentosPendentesShow', 'totalDocPendentes'));
    }

    public function gerarExcel()
    {
        return Excel::download(new AfiliadosExport(), 'afiliados.xlsx');
    }
}
